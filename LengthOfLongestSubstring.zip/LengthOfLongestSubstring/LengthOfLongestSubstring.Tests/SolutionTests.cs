using System;
using Xunit;

namespace LengthOfLongestSubstring.Tests
{
    public class SolutionTests
    {
        [Theory]
        [InlineData("abcabcbb", 3)]
        [InlineData("bbbbb", 1)]
        [InlineData("pwwkew", 3)]
        public void CaculatesTheLengthOfLongestSubstring(string str, int expected)
        {
            var actual = Solution.LengthOfLongestSubstring(str);
            Assert.Equal(expected, actual);
        }


        [Theory]
        [InlineData("")]
        [InlineData("  ")]
        [InlineData(null)]
        public void InvalidInputThrowsException(string str)
        {
            Assert.Throws<Exception>(() => Solution.LengthOfLongestSubstring(str));
        }
    }
}
