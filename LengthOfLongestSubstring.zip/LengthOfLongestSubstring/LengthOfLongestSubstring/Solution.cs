﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LengthOfLongestSubstring
{
    public static class Solution
    {
        public static int LengthOfLongestSubstring(string s)
        {
            return 0;
        }
    }
}
