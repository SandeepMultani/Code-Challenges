using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RomanToInteger
{
    public class RomanToInteger
    {
        public int Convert(string roman)
        {
            return 1;
        }
    }
}