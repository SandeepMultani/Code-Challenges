using Xunit;
using System;
using RomanToInteger;

namespace RomanToInteger.Tests;

public class RomanToIntegerTests
{
    [Theory]
    [InlineData("I", 1)]
    [InlineData("II", 2)]
    [InlineData("III", 3)]
    public void CanConvertIs(string input, int expected)
    {
        var sut = new RomanToInteger();
        var result = sut.Convert(input);
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("IV", 4)]
    [InlineData("V", 5)]
    [InlineData("VI", 6)]
    [InlineData("VIII", 8)]
    public void CanConvertVs(string input, int expected)
    {
        var sut = new RomanToInteger();
        var result = sut.Convert(input);
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("IX", 9)]
    [InlineData("X", 10)]
    [InlineData("XI", 11)]
    [InlineData("XII", 12)]
    public void CanConvertXs(string input, int expected)
    {
        var sut = new RomanToInteger();
        var result = sut.Convert(input);
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("XIV", 14)]
    [InlineData("XV", 15)]
    [InlineData("XVII", 17)]
    public void CanConvertCombinedVsAndXs(string input, int expected)
    {
        var sut = new RomanToInteger();
        var result = sut.Convert(input);
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("I", 1)]
    [InlineData("V", 5)]
    [InlineData("X", 10)]
    [InlineData("L", 50)]
    [InlineData("C", 100)]
    [InlineData("D", 500)]
    [InlineData("M", 1000)]
    public void CanConvertSingleLetterRomanNumerals(string input, int expected)
    {
        var sut = new RomanToInteger();
        var result = sut.Convert(input);
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("A")]
    [InlineData("BC")]
    public void ThrowsWhenInvalidRomanNumerals(string input)
    {
        var sut = new RomanToInteger();
        Assert.Throws<Exception>(() => sut.Convert(input));
    }
}